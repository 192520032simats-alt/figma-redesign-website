# Rapido Website UI Redesign

A student UI redesign project based on a Figma concept for a ride-hailing website.

## Project goals
- Improve visual hierarchy
- Create a clean booking section
- Present Bike-Taxi and Cab services clearly
- Highlight key offerings
- Add a driver/captain CTA
- Provide a responsive layout for desktop and mobile

## Technologies
- HTML5
- CSS3
- JavaScript

## Files
- `index.html` — webpage structure
- `style.css` — responsive styling
- `script.js` — demo interactions
- `images/` — visual assets used by the page
- `images/figma-reference.png` — reference design screenshot

## Note
This is a UI redesign/academic project and is not an official Rapido website.
