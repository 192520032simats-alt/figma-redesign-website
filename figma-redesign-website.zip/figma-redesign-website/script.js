const toast = document.getElementById("toast");

function showToast() {
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2500);
}

document.getElementById("bookRide").addEventListener("click", showToast);
document.getElementById("startEarning").addEventListener("click", showToast);
